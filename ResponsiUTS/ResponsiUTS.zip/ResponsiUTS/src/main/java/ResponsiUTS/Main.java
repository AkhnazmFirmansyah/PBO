/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ResponsiUTS;

/**
 *
 * @author Acer
 */
public class Main {
    public static void main(String[] args) {
        Elektronik hp = new Elektronik ("Realme", 1500000, 2);
        Makanan mie = new Makanan ("Indomie", 3000, "10-3-2026");
        
        PegawaiTetap pegawai1 = new PegawaiTetap("Akhnaz", 8000000, 1200000);
        PegawaiKontrak pegawai2 = new PegawaiKontrak("Vini", 4000000, 2);
        
        System.out.println("===Produk===");
        hp.tampilkanInfo();
        mie.tampilkanInfo();
        System.out.println();
        System.out.println("===Pegawai===");
        pegawai1.tampilkanInfo();
        pegawai2.tampilkanInfo();
    }
}
