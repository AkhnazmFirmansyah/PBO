/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ResponsiUTS;

/**
 *
 * @author Acer
 */
class Produk {
    private String namaproduk;
    private double harga;
    
    public Produk(String namaproduk, double harga) {
        this.namaproduk = namaproduk;
        this.harga = harga;
    }
    
    public void getNamaproduk() {
        this.namaproduk = namaproduk;
    }
    
    public void setNamaproduk() {
        this.namaproduk = namaproduk;
    }
    
    public double getHarga() {
        return harga;
    }
    
    public void setHarga(double harga) {
        this.harga = harga;
    }
    
    public void tampilkanInfo() {
        System.out.println("Nama Produk: " + namaproduk);
        System.out.println("Harga Produk: " + harga);
    }
}